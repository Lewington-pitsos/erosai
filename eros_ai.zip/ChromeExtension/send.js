var endpoint = "http://localhost:8091"

const req = new XMLHttpRequest();

req.onreadystatechange = function() { // Call a function when the state changes.
    if (this.readyState === XMLHttpRequest.DONE) {
        if (this.status === 200) {
            console.log("Got response 200!");
        } else {
            console.log("failed to send message");
        }
        
    }
}

req.open("POST", endpoint + "/process-url", true);
req.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
chrome.storage.local.get(/* String or Array */["erosai_access_token"], function(items){
    var URL = window.location.href


    if (!URL.includes(endpoint) && !URL.includes("https://www.google.com/search")) {
        req.send(JSON.stringify({
            Token: items["erosai_access_token"],
            URL: URL,
        }));
    }
});
